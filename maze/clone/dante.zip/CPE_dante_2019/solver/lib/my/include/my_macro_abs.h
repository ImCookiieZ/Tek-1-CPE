/*
** EPITECH PROJECT, 2019
** p
** File description:
** p
*/

#define ABS(value)      ((value < 0) ? (value * (-1)) : (value))