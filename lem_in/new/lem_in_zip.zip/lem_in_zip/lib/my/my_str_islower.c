/*
** EPITECH PROJECT, 2019
** y
** File description:
** nothing
*/

#include "include/my.h"

int my_str_islower(char const *str)
{
    return (0);
}
