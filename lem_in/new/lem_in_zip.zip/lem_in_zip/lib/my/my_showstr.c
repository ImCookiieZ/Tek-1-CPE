/*
** EPITECH PROJECT, 2019
** y
** File description:
** nothing
*/

#include "include/my.h"

int my_showstr(char const *str)
{
    return (0);
}
