/*
** EPITECH PROJECT, 2019
** type Controll
** File description:
** nothing
*/

#include "include/my.h"

int my_isneg(int n)
{
    if (n < 0)
        my_putchar(78);
    else
        my_putchar(80);
    return (0);
}
